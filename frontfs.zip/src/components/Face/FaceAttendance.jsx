import { useState, useRef, useEffect } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import * as faceapi from 'face-api.js';

const MODEL_URL = '/models';

export default function FaceAttendance() {
  const videoRef = useRef(null);
  const canvasRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [stream, setStream] = useState(null);
  const [attendanceResult, setAttendanceResult] = useState(null);
  const [detectedPerson, setDetectedPerson] = useState(null);
  const [recognitionActive, setRecognitionActive] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    // Load models on component mount
    const loadModels = async () => {
      try {
        // Load the face-api models - using the correct names that match the manifest files
        // Load models individually to catch specific errors
        try {
          await faceapi.nets.tinyFaceDetector.loadFromUri(MODEL_URL);
          console.log('Tiny face detector loaded successfully');
        } catch (error) {
          console.error('Error loading tiny face detector:', error);
          setError('Failed to load face detection model. Please refresh the page.');
          return; // Stop if critical model fails
        }
        
        try {
          await faceapi.nets.faceLandmark68Net.loadFromUri(MODEL_URL);
          console.log('Face landmark 68 net loaded successfully');
        } catch (error) {
          console.error('Error loading face landmark 68 net:', error);
          setError('Failed to load face landmark model. Please refresh the page.');
          return; // Stop if critical model fails
        }
        
        try {
          await faceapi.nets.faceRecognitionNet.loadFromUri(MODEL_URL);
          console.log('Face recognition net loaded successfully');
        } catch (error) {
          console.error('Error loading face recognition net:', error);
          setError('Failed to load face recognition model. Please refresh the page.');
          return; // Stop if critical model fails
        }
        console.log('Face-api models loaded successfully');
      } catch (err) {
        console.error('Error loading face-api models:', err);
        setError('Error loading face recognition models. Please try refreshing the page.');
      }
    };
    
    loadModels();
    
    // Request camera access when component mounts
    startCamera();
    
    // Start the recognition loop when component mounts
    startRecognition();
    
    return () => {
      // Clean up camera stream when component unmounts
      stopRecognition();
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  const recognizeFace = async (faceDescriptor) => {
    try {
      // Send face descriptor to backend for recognition
      const response = await fetch('http://localhost:8000/api/attendance/mark', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        },
        body: JSON.stringify({
          face_descriptor: Array.from(faceDescriptor) // Convert Float32Array to regular array
        })
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        return data.data; // Return the matched user data
      } else {
        return null; // No match found
      }
    } catch (err) {
      console.error('Error recognizing face:', err);
      return null;
    }
  };

  const startRecognition = async () => {
    if (!videoRef.current) {
      setError('Camera not available');
      return;
    }
    
    setRecognitionActive(true);
    
    const recognizeLoop = async () => {
      if (!recognitionActive) return;
      
      try {
        // Detect face in the current video frame
        const detections = await faceapi.detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
          .withFaceLandmarks()
          .withFaceDescriptors();
        
        if (detections.length > 0) {
          if (detections.length > 1) {
            // Multiple faces detected, show a warning
            setDetectedPerson({ name: 'Multiple faces detected', multiple: true });
          } else {
            // Single face detected, try to recognize it
            const faceDescriptor = detections[0].descriptor;
            const recognitionResult = await recognizeFace(faceDescriptor);
            
            if (recognitionResult) {
              setDetectedPerson({
                name: recognitionResult.user.name,
                email: recognitionResult.user.email,
                confidence: recognitionResult.confidence,
                distance: recognitionResult.distance
              });
            } else {
              setDetectedPerson({ name: 'Unknown person', unknown: true });
            }
          }
        } else {
          // No face detected
          setDetectedPerson(null);
        }
      } catch (err) {
        console.error('Error in recognition loop:', err);
      }
      
      // Schedule the next recognition after a delay
      setTimeout(recognizeLoop, 500); // Adjust this interval as needed
    };
    
    // Start the recognition loop
    recognizeLoop();
  };
  
  const stopRecognition = () => {
    setRecognitionActive(false);
    setDetectedPerson(null);
  };
  
  const startCamera = async () => {
    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'user' } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
        setStream(mediaStream);
      }
    } catch (err) {
      console.error('Error accessing camera:', err);
      setError('Could not access camera. Please check permissions.');
    }
  };

  const markAttendance = async () => {
    if (!videoRef.current) {
      setError('Camera not available');
      return;
    }

    setLoading(true);
    setError('');
    setMessage('');
    setAttendanceResult(null);

    try {
      // Detect face in the current video frame
      const detections = await faceapi.detectAllFaces(videoRef.current, new faceapi.TinyFaceDetectorOptions())
        .withFaceLandmarks()
        .withFaceDescriptors();
      
      if (detections.length === 0) {
        setError('No face detected. Please position yourself in front of the camera.');
        setLoading(false);
        return;
      }
      
      if (detections.length > 1) {
        setError('Multiple faces detected. Please ensure only your face is in the frame.');
        setLoading(false);
        return;
      }
      
      // Get the face descriptor
      const faceDescriptor = detections[0].descriptor;
      
      // Send face descriptor to backend for recognition
      const response = await fetch('http://localhost:8000/api/attendance/mark', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('authToken')}`
        },
        body: JSON.stringify({
          face_descriptor: Array.from(faceDescriptor) // Convert Float32Array to regular array
        })
      });
      
      const data = await response.json();
      
      if (response.ok && data.success) {
        setMessage(data.message || 'Attendance marked successfully!');
        setAttendanceResult(data.data);
      } else {
        setError(data.message || 'Failed to mark attendance');
      }
    } catch (err) {
      console.error('Error marking attendance:', err);
      setError('Error processing face recognition: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        <div className="bg-white rounded-lg shadow-md p-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-6">Face Attendance</h1>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Camera Section */}
            <div className="space-y-6">
              <div className="bg-gray-100 p-4 rounded-lg">
                <h2 className="text-xl font-semibold mb-4">Mark Your Attendance</h2>
                
                <div className="relative bg-black rounded overflow-hidden">
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-auto max-h-96 object-contain"
                  />
                  <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="border-2 border-white rounded-full w-48 h-48 md:w-64 md:h-64 flex items-center justify-center">
                      <div className="border-2 border-white rounded-full w-40 h-40 md:w-56 md:h-56"></div>
                    </div>
                  </div>
                </div>
                
                <div className="flex space-x-3">
                  <button
                    onClick={recognitionActive ? stopRecognition : startRecognition}
                    className={`flex-1 py-3 rounded transition font-medium ${
                      recognitionActive 
                        ? 'bg-red-600 hover:bg-red-700 text-white' 
                        : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                  >
                    {recognitionActive ? 'Stop Recognition' : 'Start Recognition'}
                  </button>
                  <button
                    onClick={markAttendance}
                    disabled={loading}
                    className={`flex-1 py-3 rounded transition font-medium ${
                      loading 
                        ? 'bg-gray-400 cursor-not-allowed' 
                        : 'bg-green-600 hover:bg-green-700 text-white'
                    }`}
                  >
                    {loading ? 'Processing...' : 'Mark Attendance'}
                  </button>
                </div>
                
                <div className="text-sm text-gray-600 mt-2">
                  {recognitionActive ? (
                    <p>Status: Real-time recognition active</p>
                  ) : (
                    <p>Status: Recognition paused</p>
                  )}
                </div>
              </div>
              
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h3 className="font-semibold text-blue-800 mb-2">Instructions:</h3>
                <ul className="text-sm text-blue-700 space-y-1">
                  <li>• Position your face within the frame</li>
                  <li>• Ensure good lighting on your face</li>
                  <li>• Look directly at the camera</li>
                  <li>• Keep a neutral expression</li>
                  <li>• Click "Mark Attendance" when ready</li>
                </ul>
              </div>
            </div>
            
            {/* Result Section */}
            <div className="space-y-6">
              <div className="bg-gray-50 p-6 rounded-lg border border-gray-200">
                <h2 className="text-xl font-semibold mb-4">Attendance Status</h2>
                
                {message && (
                  <div className="p-4 bg-green-100 text-green-700 rounded-lg mb-4">
                    {message}
                  </div>
                )}
                
                {error && (
                  <div className="p-4 bg-red-100 text-red-700 rounded-lg mb-4">
                    {error}
                  </div>
                )}
                
                {detectedPerson && (
                  <div className={`bg-white p-4 rounded-lg border ${detectedPerson.unknown ? 'border-red-200' : detectedPerson.multiple ? 'border-yellow-200' : 'border-green-200'}`}>
                    <h3 className="font-semibold mb-2">
                      {detectedPerson.multiple ? 'Multiple Faces Detected!' : 
                       detectedPerson.unknown ? 'Unknown Person' : 
                       'Recognized User'}
                    </h3>
                    <div className="space-y-2">
                      <p><span className="font-medium">Name:</span> {detectedPerson.name}</p>
                      {detectedPerson.email && (
                        <p><span className="font-medium">Email:</span> {detectedPerson.email}</p>
                      )}
                      {detectedPerson.confidence && (
                        <p><span className="font-medium">Confidence:</span> {detectedPerson.confidence}%</p>
                      )}
                      {detectedPerson.distance && (
                        <p><span className="font-medium">Match Distance:</span> {detectedPerson.distance}</p>
                      )}
                    </div>
                  </div>
                )}
                
                {attendanceResult && (
                  <div className="bg-white p-4 rounded-lg border border-green-200 mt-4">
                    <h3 className="font-semibold text-green-800 mb-2">Attendance Confirmed!</h3>
                    <div className="space-y-2">
                      <p><span className="font-medium">Name:</span> {attendanceResult.user.name}</p>
                      <p><span className="font-medium">Email:</span> {attendanceResult.user.email}</p>
                      <p><span className="font-medium">Confidence:</span> {attendanceResult.confidence}%</p>
                      <p><span className="font-medium">Match Distance:</span> {attendanceResult.distance}</p>
                    </div>
                  </div>
                )}
                
                <div className="mt-6">
                  <h3 className="font-semibold text-gray-800 mb-2">How It Works:</h3>
                  <div className="space-y-3">
                    <div className="flex items-start">
                      <div className="bg-indigo-100 text-indigo-800 rounded-full p-2 mr-3">
                        <span className="font-bold">1</span>
                      </div>
                      <p className="text-gray-600">Face recognition compares your live face with registered faces</p>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-indigo-100 text-indigo-800 rounded-full p-2 mr-3">
                        <span className="font-bold">2</span>
                      </div>
                      <p className="text-gray-600">System calculates mathematical similarity between faces</p>
                    </div>
                    
                    <div className="flex items-start">
                      <div className="bg-indigo-100 text-indigo-800 rounded-full p-2 mr-3">
                        <span className="font-bold">3</span>
                      </div>
                      <p className="text-gray-600">Attendance is marked when a match is confirmed</p>
                    </div>
                  </div>
                </div>
              </div>
              
              {user && (
                <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                  <h3 className="font-semibold text-purple-800 mb-2">Your Profile</h3>
                  <p className="text-sm text-purple-700">
                    <span className="font-medium">Logged in as:</span> {user.name} ({user.email})
                  </p>
                  <p className="text-sm text-purple-700 mt-1">
                    <span className="font-medium">Role:</span> {user.role}
                  </p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      
      {/* Hidden canvas */}
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
}